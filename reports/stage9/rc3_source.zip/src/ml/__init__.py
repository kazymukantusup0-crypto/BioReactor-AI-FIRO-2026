"""Reproducible grouped model selection."""
