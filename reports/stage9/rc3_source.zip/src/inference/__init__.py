"""Validated scientific inference."""
