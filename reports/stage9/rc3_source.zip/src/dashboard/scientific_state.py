"""Versioned scientific layers, separate from history, saved scenarios and drafts."""
import json
from src.market.domain import utcnow


def initialize(store):
    with store.connect() as con:
        columns={r['name'] for r in con.execute('PRAGMA table_info(dashboard_sessions)')}
        if 'state_version' not in columns:con.execute('ALTER TABLE dashboard_sessions ADD COLUMN state_version INTEGER NOT NULL DEFAULT 0')
        con.executescript('''
        CREATE TABLE IF NOT EXISTS scientific_tasks(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,revision INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS scientific_task_versions(task_id TEXT NOT NULL,revision INTEGER NOT NULL,state_json TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(task_id,revision));
        CREATE TABLE IF NOT EXISTS scientific_fields(task_id TEXT NOT NULL,revision INTEGER NOT NULL,layer TEXT NOT NULL,field TEXT NOT NULL,value_json TEXT NOT NULL,provenance TEXT NOT NULL,updated_at TEXT NOT NULL,source_json TEXT NOT NULL,PRIMARY KEY(task_id,revision,layer,field));
        CREATE TABLE IF NOT EXISTS dashboard_drafts(conversation_id TEXT PRIMARY KEY,revision INTEGER NOT NULL,base_state_version INTEGER NOT NULL,draft_json TEXT NOT NULL,updated_at TEXT NOT NULL);
        ''')


def persist(con,identifier,state,version):
    task_id=state.get('task_id') or 'legacy-'+identifier
    now=utcnow().isoformat()
    con.execute('INSERT INTO scientific_tasks VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,revision=excluded.revision',
                (task_id,identifier,now,now,version))
    con.execute('INSERT OR IGNORE INTO scientific_task_versions VALUES(?,?,?,?)',(task_id,version,json.dumps(state,ensure_ascii=False),now))
    for layer,key in [('confirmed','facts'),('literature','source_verified'),('assumptions','assumptions'),('derived','derived'),('predictions','estimates')]:
        for name,fact in state.get(key,{}).items():
            con.execute('INSERT OR IGNORE INTO scientific_fields VALUES(?,?,?,?,?,?,?,?)',
                        (task_id,version,layer,name,json.dumps(fact.get('value'),ensure_ascii=False),fact.get('provenance','UNKNOWN'),
                         fact.get('recorded_at') or now,json.dumps({'evidence':fact.get('evidence'),'dependencies':fact.get('dependencies',[])},ensure_ascii=False)))


def read(store,identifier):
    with store.connect() as con:
        con.execute('BEGIN')
        row=con.execute('SELECT * FROM dashboard_sessions WHERE id=?',(identifier,)).fetchone()
        if row is None:return None
        memory=json.loads(row['conversation_state_json'] or '{}')
        draft=con.execute('SELECT * FROM dashboard_drafts WHERE conversation_id=?',(identifier,)).fetchone()
        archived=[dict(r) for r in con.execute('SELECT id,revision,created_at,updated_at FROM scientific_tasks WHERE conversation_id=? ORDER BY created_at',(identifier,))]
    return {'conversation_id':identifier,'state_version':row['state_version'],'active_task_id':memory.get('task_id'),
            'confirmed_measurements':memory.get('facts',{}),'literature':memory.get('source_verified',{}),
            'assumptions':memory.get('assumptions',{}),'derived':memory.get('derived',{}),'predictions':memory.get('estimates',{}),
            'components':memory.get('mixture_components',[]),'scenario_components':memory.get('mixture_scenario_components',[]),
            'archived_tasks':archived,'dashboard_draft':dict(draft) if draft else None}
